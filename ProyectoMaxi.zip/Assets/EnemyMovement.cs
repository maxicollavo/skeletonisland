using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    public GameObject player;
    public LayerMask mask;
    public float rango = 3f;
    public GameObject bulletPrefab;
    float speed = 1.0f;
    GameObject bulletGo;

    // Start is called before the first frame update
    void Start()
    {
            
    }

    // Update is called once per frame
    void Update()
    {
        if (Physics2D.OverlapCircle(transform.position, rango, mask))
        {
            transform.position = Vector3.MoveTowards(transform.position, player.transform.position, speed * Time.deltaTime);
            if (bulletGo == null || bulletGo.activeSelf == false)
            {
                Shoot();
            }
        }
    }

    private void Shoot()
    {
        Vector3 direction = EvaluateDirection();
        bulletGo = Instantiate(bulletPrefab, transform.position, transform.rotation);
        bulletGo.GetComponent<Bullet>().dir = direction;
    }

    private Vector3 EvaluateDirection()
    {
        float x = 0, y = 0;

        if (player.transform.position.x > transform.position.x)
            x = 1;
        else if (player.transform.position.x < transform.position.x)
            x = -1;

        if (player.transform.position.y > transform.position.y)
            y = 1;
        else if (player.transform.position.y < transform.position.y)
            y = -1;

        return new Vector3(x, y, 0);
    }
}
