using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInputManager : MonoBehaviour
{
    Rigidbody2D _rb2d;
    Vector2 _dir = new Vector2(1,0);
    bool _isDashing;
    Vector2 _movement;
    Vector2 initialPosition;
    public float speed = 150;
    public float force = 20;
    public int life = 3;
    public GameObject bulletPrefab;
    public float dashDuration = 0.1f;
    float _dashingTimer;

    // Start is called before the first frame update
    void Start()
    {
        _rb2d = GetComponent<Rigidbody2D>();
        initialPosition = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.LeftShift))
        {
            Dash();
            Debug.Log("El jugador dashe�.");
        }
        var x = Input.GetAxisRaw("Horizontal");
        var y = Input.GetAxisRaw("Vertical");
        if (x != 0 || y != 0)
        {
            _dir.x = x;
            _dir.y = y;
        }
        _movement.x = x;
        _movement.y = y;
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Shoot();
            Debug.Log("El jugador dispar�.");
        }
    }

    void FixedUpdate()
    {
        Move();
    }

    void Shoot()
    {
            var bulletGo = Instantiate(bulletPrefab, transform.position, transform.rotation);
            bulletGo.GetComponent<Bullet>().dir = _dir;
    }

    void Move()
    {
        if (_isDashing)
        {
            _dashingTimer += Time.deltaTime;
            if (_dashingTimer >= dashDuration)
            {
                _isDashing = false;
                _dashingTimer = 0;
            }

        }
        else
            _rb2d.velocity = _movement * speed * Time.deltaTime;
    }

    void Dash()
    {
        _isDashing = true;
        _rb2d.AddForce(_movement * force, ForceMode2D.Impulse);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.layer == 7)
        {
            collision.gameObject.SetActive(false);
            life++;
            Debug.Log("El jugador picke� un botiqu�n.");
        }
        if (collision.gameObject.layer == 6)
        {
            life--;
            Debug.Log("El jugador choc� contra un enemigo.");
            if (life <= 0)
            {
                gameObject.SetActive(false);
                transform.position = initialPosition;
                Debug.Log("El jugador falleci�.");
            }
        }

    }
}
