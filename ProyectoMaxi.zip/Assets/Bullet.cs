using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float speed;
    [HideInInspector] public Vector3 dir;
    float lifetime;
    public int targetLayer;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        lifetime += Time.deltaTime;
        if (lifetime >= 3)
        {
            gameObject.SetActive(false);
        }
        transform.position += dir * speed * Time.deltaTime;
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.layer == targetLayer)
        {
            collision.gameObject.SetActive(false);
            Debug.Log("La bala entr� en contacto con objeto en layer " + targetLayer);
        }
    }
}
